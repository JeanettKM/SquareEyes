# CA_SquareEyes_JeanettMelsom

My CA for HTML and CSS course

Link for my prototype:

1. https://www.figma.com/file/kQTNnQY5rm2FjiN9LSAOPW/2022-09-25_Design1_CA_Jeanett_Melsom?node-id=288%3A276

2. https://www.figma.com/proto/kQTNnQY5rm2FjiN9LSAOPW/2022-09-25_Design1_CA_Jeanett_Melsom?page-id=288%3A275&node-id=288%3A276&viewport=315%2C281%2C0.25&scaling=scale-down&starting-point-node-id=288%3A276

Website link: https://hilarious-swan-92b939.netlify.app/
